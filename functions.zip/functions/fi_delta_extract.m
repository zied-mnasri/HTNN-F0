function [fi_time,fi_value,ai_value, delta_fi_time, delta_fi_value,delta_ai_value]=fi_delta_extract(s,fs)
% audiofile = 'mic_M01_sa1.wav';
% [s,fs]= audioread(audiofile);

[fi_value,ai_value]=HT_fi(s,fs);
fi_time=((0:(length(fi_value)-1))/fs)*1000;
fi_time=fi_time';

delta_fi_value = diff(fi_value)/(1/fs);
delta_ai_value = diff(ai_value)/(1/fs);
delta_fi_time = ((0:(length(delta_fi_value)-1))/fs)*1000;
delta_fi_time = delta_fi_time';