clear all
close all

downloadFolder = fullfile(tempdir,'crepeDownload');
loc = websave(downloadFolder,'https://ssd.mathworks.com/supportfiles/audio/crepe.zip');
crepeLocation = tempdir;
unzip(loc,crepeLocation)
addpath(fullfile(crepeLocation,'crepe'))

%algorithms ={'fi_f0_NN','CNN','YANG'};

noiseConditions = {'Clean', 'White', 'Babble'}; 
noiseType = input('Enter type of noise (0: Clean, 1:White, 2: Babble) ') 
if noiseType ~= 0
    snr = input('Input SNR (from 20 to 0 dB): ')
end

maxEpochs = 50;

gender = input('Choose gender of speaker (0:Male, 1:Female): ')
if gender == 0
    load (['f0_value_net_',num2str(maxEpochs),'_epochs_male.mat'])
else
    load (['f0_value_net_',num2str(maxEpochs),'_epochs_female.mat'])
end

refDirectory = 'C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\Projects\UniBD\F0-IF_DL\F0_IF_2022\Ref_Data\f0_files\';
waveDirectory = 'C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\Projects\UniBD\F0-IF_DL\F0_IF_2022\Ref_Data\wave_files\'

if gender == 0
    refDirectory = strcat(refDirectory,'Male\');
    waveDirectory = strcat(waveDirectory,'Male\');
    thrMax = 270;
    thrMin = 80;    
else 
    refDirectory = strcat(refDirectory,'Female\');
    waveDirectory = strcat(waveDirectory,'Female\');
    thrMax = 400;
    thrMin = 120;    
end

waveFiles = dir(strcat(waveDirectory,'*.wav')); 
numfiles = length(waveFiles);
mydata = cell(1, numfiles);

timeStep = 10;
numfilesTest = input('Enter the number of test files: ')
numTests = floor(numfiles/numfiles);
idxFiles = randi(numfiles, [numfilesTest,1]);
smoothing_dur = input('Enter smoothing filter period (eg. 1ms): ')
algorithmTimer = zeros(numfilesTest,numel(algorithms));
algorithmTimerSig = zeros(numfilesTest,numel(algorithms));

for k=1:numfilesTest
     display(['Processing file No ', num2str(k),' of ',num2str(numfilesTest)])
     [path,name,ext]=fileparts(waveFiles(idxFiles(k)).name);
     filename{k}=name;

    wave_filename{k}=strcat(waveDirectory,filename{k},'.wav');
    [x,fs] = audioread(wave_filename{k});
    if noiseType == 0 
        s = mean(x,2);
    elseif noiseType == 1
        whiteNoiseMaker = dsp.ColoredNoise('Color','white','SamplesPerFrame',size(x,1));
        s = mixSNR(x,whiteNoiseMaker(),snr);
    elseif noiseType == 2
        babble = audioread('babble.wav');
       s = mixSNR(x,babble,snr);
    else
        error('Enter a valid type of noise (0: clean, 1:white, 2:babble)!')
    end

        
    durSig = length(s)/fs;

    
    % Algorithm #1- Pitch detection by HTNN-F0 (Ours) with Median smoothing filter
    tic
    smoothing_filter = 0;
    [f0_est_filt, f0_est_vuv, f0_est_time] = HTNN_F0(s,fs, gender, timeStep, smoothing_filter, smoothing_dur, net);
    algorithmTimer(k,1) = toc;
    algorithmTimerSig(k,1) = toc/durSig;
    YTest{k} = f0_est_filt;

    % Algorithm #2-Pitch detection by HTNN-F0 (Ours) with linear smoothing filter
    tic
    smoothing_filter = 1;
    [f0_est_filt1, f0_est_vuv1, f0_est_time1] = HTNN_F0(s,fs, gender, timeStep, smoothing_filter, smoothing_dur, net);
    algorithmTimer(k,2) = toc;
    algorithmTimerSig(k,2) = toc/durSig;
    YTest1{k} = f0_est_filt1;

    % Algorithm #2-Pitch detection by Crepe (Matlab built-in function pitchcnn) (Benchmark #1)
    tic
    [f0,loc]=pitchnn(s,fs,'ModelCapacity','tiny','ConfidenceThreshold',0.8);
    algorithmTimer(k,3) = toc;
    algorithmTimerSig(k,3) = toc/durSig;
    f0_cnn{k} = f0;
    loc_cnn{k} = loc;

    % Algorithm #2-Pitch detection by Yang (Kawahara 2020) (Benchmark #2)
    % https://github.com/google/yang_vocoder

    addpath 'C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\Projects\UniBD\F0-IF_DL\F0_IF_New\yang_vocoder-master'
    conditions = struct('f0_floor', thrMin, ...
                'f0_ceiling', thrMax, ...
                'channels_in_octave', 12, ...
                'enable_downsampling', 1, ...
                'frame_shift', 0.010, ...
                'enable_f0_refinement', 1, ...
                'refinement_analysis_condition', ...
                GenerateAperiodicityAnalysisCondition, ...
                'tracking_condition', DefaultTrackingOptions, ...
                'vuv_setting', GenerateVUVSetting);
    
    tic
    [f0Y,vuvY]=AnalyzeSpeechSource(s,fs, conditions);
    algorithmTimer(k,4)=toc;
    algorithmTimerSig(k,4) = toc/durSig;
    f0_yang{k} = f0Y;
    vuv_yang{k} = vuvY;

end

for i = 1:numfilesTest 
   
    display(['Processing file No ', num2str(i),' of ',num2str(numfilesTest)])
    [path,name,ext]=fileparts(waveFiles(idxFiles(i)).name);
    filename{i}=name;

    %%%%%%%% F0 (Reference) %%%%%%%%%%%%%%%
    ref_filename=strcat(refDirectory,'ref',filename{i}(4:end),'.f0');
    f0_ref=importdata(ref_filename);
    
    f0_ref_value{i}=f0_ref(:,1);
    f0_ref_vuv{i}=f0_ref(:,2);
    
    truePitch = f0_ref_value{i};
    truePitch(truePitch == 0) = nan;
    TTest{i} = truePitch;     
    idxToCompare = ~isnan(TTest{i});

    f0_ref0 = TTest{i};
    vuv_ref = idxToCompare;
    f0_ref = TTest{i}(idxToCompare);
    
 
    %%%%%%%% F0 (Predictions) %%%%%%%%%%%%%%%

    % f0 predicted by HTNN-F0 with median smoothing filter
    f0_pred0 = YTest{i};
    vuv_pred = ~isnan(YTest{i});
    idxToCompare0 = idxToCompare(1:min(length(idxToCompare),length(f0_pred0)));
    f0_pred = f0_pred0(idxToCompare0);       
    [VDE(i), U2V(i), V2U(i), GPE(i), FFE(i), FPE(i)] = f0_vuv_eval_metrics(f0_ref,vuv_ref,f0_pred,vuv_pred);%,vuvThr);
   
    figure(1);
    nexttile
    plot(f0_ref0); hold on; plot(f0_pred0)
    hold on
    plot(vuv_ref*thrMax); hold on; plot(vuv_pred*thrMax)
    axis([0 length(f0_ref0) 0 thrMax+50])
   

    % f0 predicted by HTNN-F0 with linear smoothing filter
    f0_pred01 = YTest1{i};
    vuv_pred1 = ~isnan(YTest1{i});
    idxToCompare1 = idxToCompare(1:min(length(idxToCompare),length(f0_pred01)));
    f0_pred1 = f0_pred01(idxToCompare1);
    [VDE_Lin(i), U2V_Lin(i), V2U_Lin(i), GPE_Lin(i), FFE_Lin(i), FPE_Lin(i)] = f0_vuv_eval_metrics(f0_ref,vuv_ref,f0_pred1,vuv_pred1);%,vuvThr);
   
    figure(2);
    nexttile
    plot(f0_ref0); hold on; plot(f0_pred0)
    hold on
    plot(vuv_ref*thrMax); hold on; plot(vuv_pred*thrMax)
    axis([0 length(f0_ref0) 0 thrMax+50])
    
    % f0 predicted by Crepe (CNN)
    f0_pred_cnn0 = f0_cnn{i};
    vuv_pred_cnn = ~isnan(f0_cnn{i});
    idxToCompare_cnn = idxToCompare(1:min(length(idxToCompare),length(f0_pred_cnn0)));
    f0_pred_cnn = f0_pred_cnn0(idxToCompare_cnn);
    [VDE_cnn(i), U2V_cnn(i), V2U_cnn(i), GPE_cnn(i), FFE_cnn(i), FPE_cnn(i)] = f0_vuv_eval_metrics(f0_ref,vuv_ref,f0_pred_cnn,vuv_pred_cnn);
    
    figure(3);
    nexttile
    plot(f0_ref0); hold on; plot(f0_pred_cnn0)
    hold on
    plot(vuv_ref*thrMax); hold on; plot(vuv_pred_cnn*thrMax)
    axis([0 length(f0_ref0) 0 thrMax+50])

    % f0 predicted by Yang
    f0_pred_yang0 = f0_yang{i};
    vuv_pred_yang = vuv_yang{i};
    f0_pred_yang0(vuv_pred_yang==0)=nan;
    idxToCompare_yang = idxToCompare(1:min(length(idxToCompare),length(f0_pred_yang0)));
    f0_pred_yang = f0_pred_yang0(idxToCompare_yang);
    [VDE_yang(i), U2V_yang(i), V2U_yang(i), GPE_yang(i), FFE_yang(i), FPE_yang(i)] = f0_vuv_eval_metrics(f0_ref,vuv_ref,f0_pred_yang,vuv_pred_yang);

    figure(4);
    nexttile
    plot(f0_ref0); hold on; plot(f0_pred_yang0)
    hold on
    plot(vuv_ref*thrMax); hold on; plot(vuv_pred_yang*thrMax)
    axis([0 length(f0_ref0) 0 thrMax+50])

end
 
figure(1); 
sgtitle("Results of HTNN-F0-based pitch detection with median filter")
lgd = legend('Reference f0', 'Estimated f0', 'Reference VUV', 'Estimated VUV');
lgd.Layout.Tile = numfilesTest+1;

figure(2); 
sgtitle("Results of HTNN-F0-based pitch detection with linear filter")
lgd = legend('Reference f0', 'Estimated f0', 'Reference VUV', 'Estimated VUV');
lgd.Layout.Tile = numfilesTest+1;

figure(3)
sgtitle("Results of CNN-based pitch detection")
lgd = legend('Reference f0', 'Estimated f0', 'Reference VUV', 'Estimated VUV');
lgd.Layout.Tile = numfilesTest+1;

figure(4)
sgtitle("Results of Yang-based pitch detection")
lgd = legend('Reference f0', 'Estimated f0', 'Reference VUV', 'Estimated VUV');
lgd.Layout.Tile = numfilesTest+1;


Metrics = {'VDE', 'V2U', 'U2V', 'GPE', 'FFE', 'FPE'};
Voice = {'Male','Female'};
p=0.2;

% Display results for HTNN-F0 with median filter
VDE_avg = mean(VDE);
V2U_avg = mean(V2U);
U2V_avg = mean(U2V);
GPE_avg = mean(GPE);
FFE_avg = mean(FFE);
FPE_avg = mean(FPE);
Results = [VDE_avg, V2U_avg, U2V_avg, GPE_avg, FFE_avg, FPE_avg];
fprintf('\n Results for IF-based model with Median smoothing filter for %d test file(s):', numfilesTest)
fprintf('\nGPE (p = %0.2f), Noise = %s, Voice = %s\n',p,noiseConditions{noiseType+1},Voice{gender+1});
for i = 1:numel(Metrics)
    fprintf('- %s : %0.1f %%\n',Metrics{i},Results(i));
end

% Display results for HTNN-F0 with linear filter
VDE_avg_Lin = mean(VDE_Lin);
V2U_avg_Lin = mean(V2U_Lin);
U2V_avg_Lin = mean(U2V_Lin);
GPE_avg_Lin = mean(GPE_Lin);
FFE_avg_Lin = mean(FFE_Lin);
FPE_avg_Lin = mean(FPE_Lin);
Results = [VDE_avg_Lin, V2U_avg_Lin, U2V_avg_Lin, GPE_avg_Lin, FFE_avg_Lin, FPE_avg_Lin];
Metrics = {'VDE', 'V2U', 'U2V', 'GPE', 'FFE', 'FPE'};

% Display results for CNN (Crepe)
fprintf('\n Results for IF-based model with linear smoothing filter for %d test file(s):', numfilesTest)
fprintf('\nGPE (p = %0.2f), Noise = %s, Voice = %s\n',p,noiseConditions{noiseType+1},Voice{gender+1});
for i = 1:numel(Metrics)
    fprintf('- %s : %0.1f %%\n',Metrics{i},Results(i));
end
VDE_avg_cnn = mean(VDE_cnn);
V2U_avg_cnn = mean(V2U_cnn);
U2V_avg_cnn = mean(U2V_cnn);
GPE_avg_cnn = mean(GPE_cnn);
FFE_avg_cnn = mean(FFE_cnn);
FPE_avg_cnn = mean(FPE_cnn);
Results_cnn = [VDE_avg_cnn, V2U_avg_cnn, U2V_avg_cnn, GPE_avg_cnn, FFE_avg_cnn, FPE_avg_cnn];
fprintf('\n Results for CNN-based model for %d test file(s):', numfilesTest)
fprintf('\nGPE (p = %0.2f), Noise = %s, Voice = %s\n',p,noiseConditions{noiseType+1},Voice{gender+1});
for i = 1:numel(Metrics)
    fprintf('- %s : %0.1f %%\n',Metrics{i},Results_cnn(i));
end

% Display results for YANG (Kawahara 2020)
VDE_avg_yang = mean(VDE_yang);
V2U_avg_yang = mean(V2U_yang);
U2V_avg_yang = mean(U2V_yang);
GPE_avg_yang = mean(GPE_yang);
FFE_avg_yang = mean(FFE_yang);
FPE_avg_yang = mean(FPE_yang);
Results_yang = [VDE_avg_yang, V2U_avg_yang, U2V_avg_yang, GPE_avg_yang, FFE_avg_yang, FPE_avg_yang];
fprintf('\n Results for YANG model for %d test file(s):', numfilesTest)
fprintf('\nGPE (p = %0.2f), Noise = %s, Voice = %s\n',p,noiseConditions{noiseType+1},Voice{gender+1});
for i = 1:numel(Metrics)
    fprintf('- %s : %0.1f %%\n',Metrics{i},Results_yang(i));
end

% Display mean computing time (per signal and per second of speech)
algorithmTimes = mean(algorithmTimer,1)
algorithmTimesPerSec = mean(algorithmTimerSig,1)
