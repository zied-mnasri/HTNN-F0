clear all
close all

% Prepapre training data
gender = input('Choose gender of speaker (0:Male, 1:Female): ')
if gender == 0
    load f0_IF_Data_Frame_Male_Centered2.mat
else
    load f0_IF_Data_Frame_Female_Centered2.mat
end

% Remove Features with Constant Values
ConcatenatedTimesteps = cat(1,all_features_frame{:});
m = min(ConcatenatedTimesteps,[],1);
M = max(ConcatenatedTimesteps,[],1);
idxConstant = M == m;

for i = 1:numel(all_features_frame)
    all_features_frame{i}(:,idxConstant) = [];
end

numFeatures = size(all_features_frame{1},2)
numObservations = numel(all_features_frame)

% Data partition
[idxTrain,idxValidation,idxTest] = trainingPartitions(numObservations, [0.8 0.1 0.1]);

for k = 1:length(idxTrain)
    XTrain{k} = all_features_frame{idxTrain(k)};
    TTrain{k} = f0_ref_value_frame{idxTrain(k)};
end

for k = 1:length(idxValidation)
    XValidation{k} = all_features_frame{idxValidation(k)};
    TValidation{k} = f0_ref_value_frame{idxValidation(k)};
end

for k = 1:length(idxTest)
    XTest{k} = all_features_frame{idxTest(k)};
    TTest{k} = f0_ref_value_frame{idxTest(k)};
end

% Normalize Training Predictors
XTrainConcatenatedTimesteps = cat(1,XTrain{:});
mu = mean(XTrainConcatenatedTimesteps,1);
sig = std(XTrainConcatenatedTimesteps,0,1);

for i = 1:numel(XTrain)
    XTrain{i} = (XTrain{i} - mu) ./ sig;
end

% Clip Responses
if gender == 0
    thrMax = 270;
    thrMin = 80;
else 
    thrMax = 400;
    thrMin = 120;
end

for i = 1:numel(TTrain)
    TTrain{i}(TTrain{i} > thrMax) = thrMax;
    TTrain{i}(TTrain{i} < thrMin) = 0;
end

% Prepare data for padding
for i=1:numel(XTrain)
    sequence = XTrain{i};
    sequenceLengths(i) = size(sequence,1);
end

[sequenceLengths,idx] = sort(sequenceLengths,"descend");
XTrain = XTrain(idx);
TTrain = TTrain(idx);

figure
bar(sequenceLengths)
xlabel("Sequence")
ylabel("Length")
title("Sorted Data")
numResponses = size(TTrain{1},2);
numHiddenUnits = 200;

% Define Network Architecture
layers = [ ...
    sequenceInputLayer(numFeatures)
    lstmLayer(numHiddenUnits,OutputMode="sequence")
    fullyConnectedLayer(50)
    dropoutLayer(0.5)
    fullyConnectedLayer(numResponses)];

maxEpochs = input('Enter number of epochs: ');
miniBatchSize = input('Enter minibatch size: )');

options = trainingOptions("adam", ...
    MaxEpochs=maxEpochs, ...
    MiniBatchSize=miniBatchSize, ...
    InitialLearnRate=0.01, ...
    GradientThreshold=1, ...
    Shuffle="never", ...
    Metrics="rmse", ...
    Plots="training-progress", ...
    Verbose=0);

% Train the Network
net = trainnet(XTrain,TTrain,layers,"mse",options);

if gender == 0
    save(['f0_value_net_',num2str(maxEpochs),'_epochs_male.mat'], 'net')
else
    save(['f0_value_net_',num2str(maxEpochs),'_epochs_female.mat'], 'net')
end